<?php

declare(strict_types=1);

namespace NP;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\world\particle\FloatingTextParticle;

class DC extends PluginBase implements Listener {
	public
		$config,
		$cases,
		$placedCases,
		$users,
		$eco,
		$setting = [
		"set" => FALSE,
		"case" => FALSE
	];

	public function onEnable() : void {
		$f = $this->getDataFolder();
		$this->saveResource("config.yml");
		$this->saveResource("cases.yml");
		$this->config = (new Config($f . "config.yml", Config::YAML))->getAll();
		$this->cases = (new Config($f . "cases.yml", Config::YAML))->getAll();
		$this->placedCases = (new Config($f . "placedCases.yml", Config::YAML))->getAll();
		$this->usersConfig = (new Config($f . "users.yml", Config::YAML));
		$this->users = (new Config($f . "users.yml", Config::YAML))->getAll();
		$this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
		$name = strtolower($sender->getName());
		switch ($command->getName()) {
			case "casebalance":
				if (!($sender instanceof Player)) {
					$sender->sendMessage("§cТолько для игроков!");
					return FALSE;
				}
				$sender->sendMessage(str_replace("{keys}", (string) $this->users[$name]["cases"]["donate"], $this->config["messages"]["keys"]));
				break;
			case "caseset":
				if (!($sender instanceof Player)) {
					$sender->sendMessage("§cТолько для игроков!");
					return FALSE;
				}
				if (count($args) != 1) {
					$sender->sendMessage("§f(§cКейсы§f)§r §fИспользование: /caseset <имя кейса>");
					return TRUE;
				}
				$case = strtolower($args[0]);
				if (!isset($this->cases[$case])) {
					$sender->sendMessage("§f(§cКейсы§f)§r §fТакого кейса не существует");
					return TRUE;
				}
				$this->setting["set"] = TRUE;
				$this->setting["case"] = $case;
				$sender->sendMessage("§f(§cКейсы§f)§r §fНажмите туда, куда хотите установить кейс");
				break;
			case "casecoins":
				if (!$this->config["param"]["players"] && $sender instanceof Player) {
					return TRUE;
				}
				if (!isset($args[2])) {
					$sender->sendMessage("§f(§cКейсы§f)§r §fИспользование: /cc <ник> <количество> <тип>");
					return TRUE;
				}
				$name = strtolower($args[0]);
				if (isset($this->users[$name])) {
					$this->users[$name]["cases"][$args[2]] += (int) $args[1];
				} else {
					$this->usersConfig->set($name, (int) $args[1]);
				}
				$sender->sendMessage("§f(§cКейсы§f)§r §fИгроку §c$name §fвыдано §c$" . (int) $args[1] . " §fключей");
				$this->getLogger()->info("§f(§cКейсы§f)§r §fИгроку §c$name §fвыдано §c$" . (int) $args[1] . " §fключей");
				$this->save();
				break;
		}
		return TRUE;
	}

	public function onPlayerInteract(PlayerInteractEvent $event) {
		$player = $event->getPlayer();
		$name = strtolower($player->getName());
		$block = $event->getBlock();
		$x = $block->getPosition()->getFloorX();
		$y = $block->getPosition()->getFloorY();
		$z = $block->getPosition()->getFloorZ();
		if ($player->hasPermission("newplugin.caseset")) {
			if ($this->setting["set"]) {
				$event->cancel();
				$this->setting["set"] = FALSE;
				$cName = $this->setting["case"];
				$case = $this->cases[$cName];
				$this->placedCases["$x.$y.$z"] = $case;
				$this->placedCases["$x.$y.$z"]["world"] = strtolower($player->getWorld()->getFolderName());
				$this->saveCase();
				$player->sendMessage("§f(§cКейсы§f)§r §fКейс §c$cName §fустановлен на §c$x $y $z");
				$player->sendMessage("§f(§cКейсы§f)§r §fУдалять кейс через конфиг!");
				$this->addText($player, ["x" => $x + 0.5, "y" => $y + 1.2, "z" => $z + 0.6], $case["title"]);
				return TRUE;
			}
		}
		if (isset($this->placedCases["$x.$y.$z"])) {
			$event->cancel();
			$case = $this->placedCases["$x.$y.$z"];
			if ($this->users[$name]["cases"][$case["type"]] < 1) {
				$player->sendMessage($this->config["messages"]["noKey"]);
				return TRUE;
			}
			$this->users[$name]["cases"][$case["type"]]--;
			$win = $this->getWin($case["items"]);
			switch ($case["type"]) {
				case "donate":
					$this->getServer()->getInstance()->dispatchCommand(new ConsoleCommandSender($this->getServer(), $this->getServer()->getLanguage()), str_replace("{player}", $name, $win["command"]));
					$win["count"] = 1;
					break;
				case "bonus":
					$count = explode("/", $win["count"]);
					if (!isset($count[1])) {
						$count[1] = $count[0];
					}
					$count = mt_rand($count[0], $count[1]);
					$win["count"] = $count;
					$this->eco->addMoney($name, $count);
					break;
			}
			$player->sendMessage(str_replace(["{item}", "{count}"], [$win["chat"], $win["count"]], $this->config["messages"]["win"]));
			if ($this->config["param"]["broadcast"]) {
				$this->getServer()->broadcastMessage(str_replace(["{player}", "{item}", "{count}"], [$player->getName(), $win["chat"], (string) $win["count"]], $this->config["messages"]["broadcast"]));
			}
			$this->save();
		}
	}

	public function onPlayerJoin(PlayerJoinEvent $event) {
		$name = strtolower($event->getPlayer()->getName());
		foreach ($this->placedCases as $coords => $case) {
			$coords = explode(".", $coords);
			$this->addText($event->getPlayer(), ["x" => $coords[0] + 0.5, "y" => $coords[1] + 1.2, "z" => $coords[2] + 0.6], $case["title"]);
		}
		if (!isset($this->users[$name])) {
			$this->users[$name]["day"] = -time();
			$this->users[$name]["cases"] = [
				"donate" => 0,
				"bonus" => 0
			];
		}
		if ($this->users[$name]["day"] < time()) {
			$this->users[$name]["cases"]["bonus"]++;
			$this->users[$name]["day"] = time() + 86400;
		}
		$this->save();
	}

	public function openCase($player, $amount) {
		$this->eco->setMoney($player, $this->eco->myMoney($player) - $amount);
	}

	public function saveCase() {
		$cfg = new Config($this->getDataFolder() . "placedCases.yml", Config::YAML);
		$cfg->setAll($this->placedCases);
		$cfg->save();
		unset($cfg);
	}

	public function save() {
		$cfg = new Config($this->getDataFolder() . "users.yml", Config::YAML);
		$cfg->setAll($this->users);
		$cfg->save();
		unset($cfg);//
	}

	private function getWin($list) {
		do {
			$item = $list[array_rand($list)];
			$chance = mt_rand(1, 100);
			if ($chance <= $item["chance"]) {
				return $item;
			}
		} while ($chance > $item["chance"]);
	}

	private function addText($player, $coords, $text) {
		$player->getWorld()->addParticle(new Vector3($coords["x"], $coords["y"], $coords["z"]), new FloatingTextParticle(str_replace("\n", "\n", $text), ""));
	}
}

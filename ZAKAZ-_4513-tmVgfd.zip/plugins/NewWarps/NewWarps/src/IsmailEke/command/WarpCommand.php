<?php

namespace IsmailEke\command;

use IsmailEke\Warp;
use IsmailEke\form\WarpForm;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\MainLogger;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

class WarpCommand extends Command
{
	
	public function __construct ()
	{
		parent::__construct("warp", "Варпы", "/warp");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param array $args
	*/
	
	public function execute (CommandSender $sender, string $commandLabel, array $args)
	{
		if ($sender instanceof Player) {
			if (empty($args[0])) {
				if (empty($args[1])) {
					$sender->sendForm(new WarpForm());
				}
			} else {
					if ($args[0] === "create") {
						if (!empty($args[1])) {
							$warps = [];
					  foreach (Warp::$warpConfig->get("Warps") as $key => $value) {
						$warps[] = $key;
					}
					$array_search = array_search($args[1], $warps);
							if ($array_search !== false) {
								$sender->sendMessage(TextFormat::RED."Варп уже существует.");
					  } else {
					         $pos = $sender->getPosition();
						  Warp::$warpConfig->setNested("Warps.".$args[1], [
						  "PositionX" => $pos->getX(),
						  "PositionY" => $pos->getY(),
						  "PositionZ" => $pos->getZ(),
						  ]);
						  Warp::$warpConfig->save();
						  $sender->sendMessage(TextFormat::GREEN."Варп успешно создан.");
					  }
						} else {
							$sender->sendMessage(TextFormat::RED."Использование: /warp <create/remove> <название>");
						}
				 } elseif ($args[0] === "remove") {
				 	 if (!empty($args[1])) {
				 	 	 $warps = [];
					  foreach (Warp::$warpConfig->get("Warps") as $key => $value) {
						$warps[] = $key;
					}
					$array_search = array_search($args[1], $warps);
					if($array_search !== false) {
						Warp::$warpConfig->removeNested("Warps.".$args[1]);
						$sender->sendMessage(TextFormat::GREEN."Варп ".$args[1]." успешно удалён.");
					} else {
						$sender->sendMessage(TextFormat::RED."Варп не найден.");
					}
				  } else {
				  	$sender->sendMessage(TextFormat::RED."Использование: /warp <create/remove> <название>");
				  }
				 } else {
					 $sender->sendMessage(TextFormat::RED."Использование: /warp <create/remove> <название>");
				 }
				}
		} 
	}
}
?>
<?php

/*
*
* Warp Plugin
*
* Author: IsmailEke (İsmail Eke)
* GitHub: IsmailEke
* YouTube: İsmail Eke
* Discord: IsmailEke#2359
*
*/

namespace IsmailEke;

use IsmailEke\manager\CommandManager;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\MainLogger;
use pocketmine\utils\Config;

class Warp extends PluginBase
{
	
	/** @var Config */
	
	public static $warpConfig;
	
	public function onEnable () : void{
                foreach(array_diff(scandir($this->getServer()->getDataPath() . "worlds"), ["..", "."]) as $levelName){
		    $this->getServer()->getWorldManager()->loadWorld($levelName);
                }
		//MainLogger::getLogger()->notice("Warp Plugin Online");
		CommandManager::register();
		if (file_exists($this->getDataFolder() ."warp.yml")) {
		    self::$warpConfig = new Config($this->getDataFolder() . "warp.yml", Config::YAML);
		} else {
		    @mkdir($this->getDataFolder());
		    self::$warpConfig = new Config($this->getDataFolder() . "warp.yml", Config::YAML);
		    self::$warpConfig->set("Warps", []);
		    self::$warpConfig->save();
		}
    }
	
	public function onDisable () : void{
		//MainLogger::getLogger()->alert("Warp Plugin Offline");
	}
}
?>

<?php

declare(strict_types=1);

namespace JonyGamesYT9\SimpleBroadcast\Scheduler;

use JonyGamesYT9\SimpleBroadcast\Provider\YamlProvider;
use pocketmine\player\Player;
use pocketmine\Server;
use function array_rand;
use function count;
use function str_replace;

/**
 * Class BroadcastScheduler
 * @package JonyGamesYT9\SimpleBroadcast\Scheduler
 */
class BroadcastScheduler extends \pocketmine\scheduler\Task {
	/**
	 * @return void
	 */
	public function onRun() : void {
		$messages = YamlProvider::getInstance()->getMessages();
		$random = $messages[array_rand($messages)];
		$title = YamlProvider::getInstance()->getPrefix();
		$online = count(Server::getInstance()->getOnlinePlayers());
		foreach (Server::getInstance()->getOnlinePlayers() as $players) {
			if ($players instanceof Player) {
				$selected_message = str_replace(["&", "{online}", "{name}"], ["§", $online, $players->getName()], $random);
				$players->sendMessage(str_replace(["&"], ["§"], $title) . " " . $selected_message);
			}
		}
	}
}

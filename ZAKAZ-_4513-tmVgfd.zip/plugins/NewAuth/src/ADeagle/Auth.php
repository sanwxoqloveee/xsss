<?php

declare(strict_types=1);

namespace ADeagle;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Auth extends PluginBase implements Listener {
	private $db, $users = array(), $reg = array();

	public function onEnable() : void {
		if (!is_dir($this->getDataFolder())) {
			@mkdir($this->getDataFolder());
		}

		$this->config = (new Config($this->getDataFolder() . "config.yml", Config::YAML, ["salt" => "Drag"]))->getAll();
		$this->db = new \SQLite3($this->getDataFolder() . "users.db");
		$this->db->exec(stream_get_contents($this->getResource("database.sql")));
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function noMove(PlayerMoveEvent $e) {
		if (!isset($this->users[strtolower($e->getPlayer()->getName())])) {
			$e->cancel();
		}
	}

	public function onDrop(PlayerDropItemEvent $e) {
		if (!isset($this->users[strtolower($e->getPlayer()->getName())])) {
			$e->cancel();
		}
	}

	public function onBreak(BlockBreakEvent $e) {
		if (!isset($this->users[strtolower($e->getPlayer()->getName())])) {
			$e->cancel();
		}
	}

	public function onTap(PlayerInteractEvent $e) {
		if (!isset($this->users[strtolower($e->getPlayer()->getName())])) {
			$e->cancel();
		}
	}

	public function noPlace(BlockPlaceEvent $e) {
		if (!isset($this->users[strtolower($e->getPlayer()->getName())])) {
			$e->cancel();
		}
	}

	public function noEat(PlayerItemConsumeEvent $e) {
		if (!isset($this->users[strtolower($e->getPlayer()->getName())])) {
			$e->cancel();
		}
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
		switch ($command->getName()) {
			case "cp":
				$name = strtolower($sender->getName());
				if (isset($args[0]) && isset($args[1])) {
					$pass = @crypt($args[0], $this->config["salt"]);
					$sql = $this->db->query("SELECT * FROM `users` WHERE `nickname` = '$name'")->fetchArray(SQLITE3_ASSOC);
					$new = $args[1];
					$ip = $sql["ipReg"];
					$add = $this->db->prepare("INSERT OR REPLACE INTO users (nickname, password, ipReg, ipLast) VALUES (:nickname, :password, :ipReg, :ipLast)");
					$add->bindValue(":nickname", $name);
					$add->bindValue(":password", crypt($new, $this->config["salt"]));
					$add->bindValue(":ipReg", $ip);
					$add->bindValue(":ipLast", $ip);
					$result = $add->execute();
					$sender->sendMessage("§c> §fПароль изменён на §l§c$new.§r");
				} else {
					$sender->sendMessage("§c> §fСменить пароль : §l§c/cp [новый пароль]");
				}
				break;

			case "mail":
				$sender->sendMessage("\n\n§8(§bПочта§8)§e × §fЕсли вдруг кто-то попытается §aвойти§f в твой аккаунт, тебе на §eигровую§f почту будет отправлено §cписьмо§f!\n§r");
				break;
		}
		return TRUE;
	}

	public function onPlayerJoin(PlayerJoinEvent $e) {
		$player = $e->getPlayer();
		$sql = $this->db->prepare("SELECT * FROM `users` WHERE `nickname` = :nickname");
		$sql->bindValue(":nickname", strtolower($player->getName()), SQLITE3_TEXT);
		$sql = $sql->execute();
		$user = $sql->fetchArray(SQLITE3_ASSOC);
		if (isset($user["nickname"])) {
			$ip = $player->getNetworkSession()->getIp();
			if ($ip == $user["ipLast"]) {
				$this->users[strtolower($player->getName())] = [
					"pass" => $user["password"],
					"ip" => $ip,
				];
				$player->setImmobile(FALSE);
				$player->sendMessage("§c> §fВы §l§cвошли §r§fпо §l§cIP.§r\n§c> §fПароль §l§cвводить §r§fне нужно.§l");

				$player->setImmobile(FALSE);
			} else {
				$player->sendMessage("§c> §fВведите пароль чтобы §l§cавторизоваться.§r");
				$player->setImmobile(TRUE);
			}
		} else {
			$player->sendMessage("§c> §fВведите пароль чтобы §l§cзарегистрироваться.§r");
			$player->setImmobile(TRUE);
			$sql->finalize();
		}
	}

	public function onPlayerQuit(PlayerQuitEvent $e) {
		unset($this->users[strtolower($e->getPlayer()->getName())]);
	}

	public function PlayerRespawnEvent(PlayerRespawnEvent $e) {
		$p = $e->getPlayer();
		$p->setMaxHealth(40);
		$p->setHealth(40);
	}

	public function onPlayerCommandPreprocess(PlayerCommandPreprocessEvent $e) {
		$login = "§c> §fВведите пароль чтобы §l§cавторизоваться.§r";
		$player = $e->getPlayer();
		$name = strtolower($player->getName());
		$ip = $player->getNetworkSession()->getIp();
		$msg = $e->getMessage();
		if (!isset($this->users[$name])) {
			if (count(explode("/", $msg)) > 1) {
				$e->cancel();
				$player->sendMessage($login);
			} else {
				$msg = explode(" ", $msg);
				if (count($msg) == 1) {
					$sql = $this->db->prepare("SELECT * FROM `users` WHERE `nickname` = :nickname");
					$sql->bindValue(":nickname", $name, SQLITE3_TEXT);
					$sql = $sql->execute();
					if ($sql instanceof \SQLite3Result) {
						$pass = crypt($msg[0], $this->config["salt"]);
						$user = $sql->fetchArray(SQLITE3_ASSOC);
						if (!empty($user["nickname"])) {
							if ($pass == $user["password"]) {
								$upd = $this->db->prepare("UPDATE `users` SET `ipLast` = :ip WHERE `nickname` = :nickname");
								$upd->bindValue(":ip", $ip);
								$upd->bindValue(":nickname", $name);
								$upd = $upd->execute();
								$upd->finalize();
								$this->users[$name] = [
									"pass" => $pass,
									"ip" => $ip,
								];
								$player->sendMessage("\n§l§aВы успешно авторизировались!\n§fСмена пароля §d/cp");
								$player->setImmobile(FALSE);
							} else {
								$player->sendMessage("§c> §fВведён §l§cневерный §r§fпароль.§r");
							}
						} else {
							if (!isset($this->reg[$name])) {
								$this->reg[$name] = $pass;
								$player->sendMessage("§c> §fВведите §l§cпароль §r§fеще раз.§r");
							} else {
								if ($pass == $this->reg[$name]) {
									$add = $this->db->prepare("INSERT INTO `users`(`nickname`, `password`, `ipReg`, `ipLast`) VALUES(:nickname, :password, :ip, :ip)");
									$add->bindValue(":nickname", $name);
									$add->bindValue(":password", $pass);
									$add->bindValue(":ip", $ip);
									$add = $add->execute();
									$add->finalize();
									$this->users[$name] = [
										"pass" => $pass,
										"ip" => $ip,
									];
									$player->setImmobile(FALSE);
									$player->sendMessage("§c> §fВы успешно §l§cзарегистрировались.§r");
									// $this->getServer()->dispatchCommand($player, "kit start");
									$player->setMaxHealth(40);
									$player->setHealth(40);
									$player->setImmobile(FALSE);
								} else {
									unset($this->reg[$name]);
									$player->sendMessage("§c> §fВведён §l§cневерный §r§fпароль.§r");
								}
							}
						}
					}
					$sql->finalize();
				} else {
					$player->sendMessage($login);
				}
			}
			$e->cancel();
		} else {
			if ($ip != $this->users[$name]["ip"]) {
				$e->cancel();
				$player->sendMessage($login);
			}
		}
	}
}

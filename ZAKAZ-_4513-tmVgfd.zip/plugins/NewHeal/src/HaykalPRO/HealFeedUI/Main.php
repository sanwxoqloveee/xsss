<?php

namespace HaykalPRO\HealFeedUI;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase {
    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        switch ($cmd->getName()) {
            case "hfui":
                if (!($sender instanceof Player)) {
                    $sender->sendMessage("§cВы должны быть игроком!");
                    return true;
                }
                if (!$sender->hasPermission("heal.use")) {
                    $sender->sendMessage("§cНет прав!");
                    return true;
                }
                $this->openMyForm($sender);
                return true;
        }
    }

    public function openMyForm(Player $sender) {
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $player, int $data = null) {
            $result = $data;
            if ($result === NULL) {
                return true;
            }
            switch ($result) {
                case 0:
                    $player->setHealth(20);
                    $player->sendMessage("§cВаше здоровье восстановлено!");
                    break;
                case 1:
                    $player->getHungerManager()->setFood(20);
                    $player->sendMessage("§cВаш голод восстановлен!");
                    break;
            }
        });
        $form->setTitle("§c§lВылечить себя");
        $form->setContent("§fВыберите действие:");
        $form->addButton("Восстановить здоровье");
        $form->addButton("Восстановить голод");
        $form->sendToPlayer($sender);
        return $form;
    }
}

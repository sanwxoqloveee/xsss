<?php

declare(strict_types=1);


namespace diduhless\reports\report\form;


use diduhless\reports\report\Report;
use diduhless\reports\report\ReportFactory;
use diduhless\reports\Reports;
use diduhless\reports\session\SessionFactory;
use diduhless\reports\libs\EasyUI\element\Dropdown;
use diduhless\reports\libs\EasyUI\element\Option;
use diduhless\reports\libs\EasyUI\utils\FormResponse;
use diduhless\reports\libs\EasyUI\variant\CustomForm;
use pocketmine\player\Player;
use pocketmine\Server;

class ReportForm extends CustomForm {

    public function __construct() {
        parent::__construct("Подать жалобу");
    }

    protected function onCreation(): void {
        $players_dropdown = new Dropdown("Выберите игрока");
        foreach(Server::getInstance()->getOnlinePlayers() as $player) {
            $players_dropdown->addOption(new Option($username = $player->getName(), $username));
        }

        $reasons_dropdown = new Dropdown("Выберите причину");
        foreach(Reports::getInstance()->getConfig()->get("report.reasons") as $reason) {
            $reasons_dropdown->addOption(new Option($reason, $reason));
        }

        $this->addElement("players_dropdown", $players_dropdown);
        $this->addElement("reasons_dropdown", $reasons_dropdown);
    }

    protected function onSubmit(Player $player, FormResponse $response): void {
        $target_username = $response->getDropdownSubmittedOptionId("players_dropdown");

        $sender_session = SessionFactory::getSession($player);
        $target_session = SessionFactory::getSessionByName($target_username);

        if($target_session === null) {
            $sender_session->message("{RED}Игрок {WHITE}$target_username {RED}оффлайн!");
            return;
        }
        $reason = $response->getDropdownSubmittedOptionId("reasons_dropdown");

        $report = new Report($sender_session, $target_session, $reason);
        $report->send();

        ReportFactory::registerReport($report);
    }

}

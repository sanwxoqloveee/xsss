<?php

declare(strict_types=1);

namespace NewPlugin\NewRTP;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\world\Position;
use function mt_rand;

class Main extends PluginBase {
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
		if (!($sender instanceof Player)) {
			$sender->sendMessage("§f(§cТелепортация§f) Только в игре!");
			return TRUE;
		}
		$sender->teleport(new Position(mt_rand(-1500, 1500), 128, mt_rand(-1500, 1500), $sender->getWorld()));
		$sender->getEffects()->add(new EffectInstance(VanillaEffects::RESISTANCE(), 200, 255, FALSE));
		$sender->sendMessage("§f(§cТелепортация§f) Вы §cуспешно§f телепортированы!");
		return TRUE;
	}
}
<?php

declare(strict_types=1);

namespace NewPlugin\NewGM;

use NewPlugin\NewGM\listeners\EventListener;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Main extends PluginBase {
	public function onEnable() : void {
		$this->getServer()->getPluginManager()->registerEvents(new EventListener(
			new Config($this->getDataFolder() . "creative.json", Config::JSON),
			new Config($this->getDataFolder() . "survival.json", Config::JSON)
		), $this);
	}
}
<?php

declare(strict_types=1);

namespace NewPlugin\NewGM\listeners;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerGameModeChangeEvent;
use pocketmine\item\Item;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\world\sound\PopSound;
use function strtolower;
use const JSON_BIGINT_AS_STRING;

class EventListener implements Listener {
	private array $creative;
	private array $survival;

	public function __construct(
		private Config $cConfig,
		private Config $sConfig
	) {
		$this->cConfig->setJsonOptions(JSON_BIGINT_AS_STRING);
		$this->sConfig->setJsonOptions(JSON_BIGINT_AS_STRING);

		$this->creative = $this->cConfig->getAll();
		$this->survival = $this->sConfig->getAll();
	}

	/**
	 * @param PlayerGameModeChangeEvent $event
	 * @priority LOWEST
	 *
	 * @return void
	 */
	public function onPlayerGameModeChange(PlayerGameModeChangeEvent $event) : void {
		if (($player = $event->getPlayer())->hasPermission("newplugin.gmbypass")) return;

		$name = strtolower($player->getName());

		if (!isset($this->creative[$name])) $this->creative[$name] = [
			"inventory" => [],
			"armor" => []
		];
		if (!isset($this->survival[$name])) $this->survival[$name] = [
			"inventory" => [],
			"armor" => []
		];

		$inv = []; /** @var Item[] $inv */
		$armor = []; /** @var Item[] $armor */

		$currInv = [];
		$currArmor = [];

		foreach ($player->getInventory()->getContents(TRUE) as $item) $currInv[] = $item->jsonSerialize();
		foreach ($player->getArmorInventory()->getContents(TRUE) as $item) $currArmor[] = $item->jsonSerialize();

		if ($event->getNewGamemode() !== GameMode::CREATIVE()) {
			foreach ($this->survival[$name]["inventory"] as $item) $inv[] = Item::jsonDeserialize($item);
			foreach ($this->survival[$name]["armor"] as $item) $armor[] = Item::jsonDeserialize($item);

			$this->creative[$name] = [
				"inventory" => $currInv,
				"armor" => $currArmor
			];

			$this->save();
			$player->getInventory()->setContents($inv);
			$player->getArmorInventory()->setContents($armor);
			return;
		}

		foreach ($this->creative[$name]["inventory"] as $item) $inv[] = Item::jsonDeserialize($item);
		foreach ($this->creative[$name]["armor"] as $item) $armor[] = Item::jsonDeserialize($item);

		$this->survival[$name] = [
			"inventory" => $currInv,
			"armor" => $currArmor
		];

		$this->save();
		$player->getInventory()->setContents($inv);
		$player->getArmorInventory()->setContents($armor);

		$this->playSound($player);
	}

	private function save() {
		$this->cConfig->setAll($this->creative);
		$this->cConfig->save();

		$this->sConfig->setAll($this->survival);
		$this->sConfig->save();
	}

	private function playSound(Player $player) : void {
		$player->broadcastSound(new PopSound(), [$player]);
	}
}

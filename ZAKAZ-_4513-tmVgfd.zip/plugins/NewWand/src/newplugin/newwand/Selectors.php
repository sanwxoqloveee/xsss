<?php

declare(strict_types=1);

namespace newplugin\newwand;

use InvalidArgumentException;
use JetBrains\PhpStorm\Pure;
use newplugin\newwand\math\Math;
use pocketmine\player\Player;
use pocketmine\utils\AssumptionFailedError;
use pocketmine\world\Position;
use function array_key_exists;

class Selectors {
	/** @var Position[] */
	private static array $pos1 = [];
	/** @var Position[] */
	private static array $pos2 = [];
	/** @var Player[] */
	private static array $wandSelectors = [];
	/** @var Player[] */
	private static array $blockInfoPlayers = [];

	/**
	 * @return int|null If not null, returns count of blocks in selection
	 */
	public static function addSelector(Player $player, int $pos, Position $position) : ?int {
		if ($pos !== 1 && $pos !== 2) {
			throw new InvalidArgumentException("Нужно выбрать 2 позиции");
		}
		if (!$position->equals($position->ceil())) {
			throw new InvalidArgumentException("Ошибка в координатах.");
		}

		if ($pos === 1) {
			Selectors::$pos1[$player->getName()] = $position;
		} else {
			Selectors::$pos2[$player->getName()] = $position;
		}

		$pos1 = Selectors::$pos1[$player->getName()] ?? NULL;
		$pos2 = Selectors::$pos2[$player->getName()] ?? NULL;

		if ($pos1 === NULL || $pos2 === NULL || !$pos1->getWorld()->isLoaded() || !$pos2->getWorld()->isLoaded() || $pos1->getWorld()->getId() !== $pos2->getWorld()->getId()) {
			return NULL;
		}

		return Math::selectionSize($pos1, $pos2);
	}

	public static function getPosition(Player $player, int $pos) : Position {
		if ($pos === 1) {
			return Selectors::$pos1[$player->getName()];
		}
		if ($pos === 2) {
			return Selectors::$pos2[$player->getName()];
		}

		throw new AssumptionFailedError("{$player->getDisplayName()} не имеет позиций");
	}

	#[Pure] public static function isSelected(int $pos, Player $player) : bool {
		if ($pos === 1) {
			return array_key_exists($player->getName(), Selectors::$pos1);
		}
		if ($pos === 2) {
			return array_key_exists($player->getName(), Selectors::$pos2);
		}

		return FALSE;
	}

	public static function switchWandSelector(Player $player) : void {
		if (array_key_exists($player->getName(), Selectors::$wandSelectors)) {
			unset(Selectors::$wandSelectors[$player->getName()]);
		} else {
			Selectors::$wandSelectors[$player->getName()] = $player;
		}
	}

	public static function switchBlockInfoSelector(Player $player) : void {
		if (array_key_exists($player->getName(), Selectors::$blockInfoPlayers)) {
			unset(Selectors::$blockInfoPlayers[$player->getName()]);
		} else {
			Selectors::$blockInfoPlayers[$player->getName()] = $player;
		}
	}

	#[Pure] public static function isWandSelector(Player $player) : bool {
		return array_key_exists($player->getName(), Selectors::$wandSelectors);
	}

	#[Pure] public static function isBlockInfoPlayer(Player $player) : bool {
		return array_key_exists($player->getName(), Selectors::$blockInfoPlayers);
	}

	public static function unloadPlayer(Player $player) : void {
		unset(
			Selectors::$wandSelectors[$player->getName()],
			Selectors::$blockInfoPlayers[$player->getName()],
			Selectors::$pos1[$player->getName()],
			Selectors::$pos2[$player->getName()]
		);
	}
}
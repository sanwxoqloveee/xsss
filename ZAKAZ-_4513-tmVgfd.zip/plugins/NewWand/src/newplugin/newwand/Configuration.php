<?php

declare(strict_types=1);

namespace newplugin\newwand;

use newplugin\newwand\utils\IncompatibleConfigException;
use function explode;
use function is_array;
use function is_bool;
use function is_int;
use function is_string;

class Configuration {
	public function __construct(/** @var array<array-key, mixed> $data */ private array $data) {
	}

	public function getIntProperty(string $key) : int {
		if (!is_int($property = $this->getProperty($key))) {
			throw new IncompatibleConfigException("Property '$key' should be int type");
		}
		return $property;
	}

	public function getBoolProperty(string $key) : bool {
		if (!is_bool($property = $this->getProperty($key))) {
			throw new IncompatibleConfigException("Property '$key' should be bool type");
		}
		return $property;
	}

	public function getStringProperty(string $key) : string {
		if (!is_string($property = $this->getProperty($key))) {
			throw new IncompatibleConfigException("Property '$key' should be string type");
		}
		return $property;
	}

	/**
	 * @throws IncompatibleConfigException
	 */
	public function getProperty(string $key) : mixed {
		$property = $this->data;
		foreach (explode(".", $key) as $part) {
			$property = $property[$part] ?? []; // @phpstan-ignore-line
		}

		if (is_array($property)) {
			throw new IncompatibleConfigException("Config option $key is not set");
		}

		return $property;
	}
}
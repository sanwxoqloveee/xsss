<?php

declare(strict_types=1);

namespace newplugin\newwand;

use newplugin\newwand\commands\FillCommand;
use newplugin\newwand\commands\FirstPositionCommand;
use newplugin\newwand\commands\SecondPositionCommand;
use newplugin\newwand\commands\WandCommand;
use newplugin\newwand\event\listener\EventListener;
use newplugin\newwand\math\Math;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use function array_key_exists;
use function glob;
use function is_dir;
use function is_file;
use function is_string;
use function mkdir;
use function rename;
use function unlink;
use function version_compare;

class NewWand extends PluginBase {
	public const CURRENT_CONFIG_VERSION = "1.3.0.0";
	private static self $instance;
	private static Configuration $configuration;
	/** @var Command[] */
	private static array $commands = [];

	/** @noinspection PhpUnused */

	/**
	 * @return Command[]
	 */
	public static function getAllCommands() : array {
		return self::$commands;
	}

	/** @noinspection PhpUnused */

	public static function getPrefix() : string {
		return "§7[NewWand] §a";
	}

	public static function getConfiguration() : Configuration {
		return self::$configuration;
	}

	public static function getInstance() : NewWand {
		return self::$instance;
	}

	public function sendWarnings() : void {
		if ($this->getServer()->getConfigGroup()->getProperty("memory.async-worker-hard-limit") !== 0) {
			$this->getServer()->getLogger()->warning("We recommend to disable 'memory.async-worker-hard-limit' in pocketmine.yml. By disabling this option will be NewWand able to load bigger schematic files.");
		}
	}

	public function cleanCache() : void {
		if (!self::getConfiguration()->getBoolProperty("clean-cache")) {
			return;
		}

		$files = glob($this->getDataFolder() . "sessions/*.dat");
		if ($files === FALSE) {
			return;
		}

		/** @var string $offlineSession */
		foreach ($files as $offlineSession) {
			unlink($offlineSession);
		}
	}

	protected function onEnable() : void {
		NewWand::$instance = $this;

		$this->initConfig();
		$this->cleanCache();
		$this->registerCommands();
		$this->initMath();
		$this->initListener();
		$this->sendWarnings();
	}

	protected function onDisable() : void {
		$this->cleanCache();
	}

	private function initConfig() : void {
		if (!is_dir($this->getDataFolder() . "schematics")) {
			@mkdir($this->getDataFolder() . "schematics");
		}
		if (!is_dir($this->getDataFolder() . "sessions")) {
			@mkdir($this->getDataFolder() . "sessions");
		}
		if (!is_dir($this->getDataFolder() . "data")) {
			@mkdir($this->getDataFolder() . "data");
		}
		if (!is_file($this->getDataFolder() . "data/bedrock_block_states_map.json")) {
			$this->saveResource("data/bedrock_block_states_map.json");
		}
		if (!is_file($this->getDataFolder() . "data/java_block_states_map.json")) {
			$this->saveResource("data/java_block_states_map.json");
		}

		$configuration = $this->getConfig()->getAll();
		if (!array_key_exists("config-version", $configuration) || !is_string($version = $configuration["config-version"]) || version_compare($version, NewWand::CURRENT_CONFIG_VERSION) < 0) {
			// Update is required
			@unlink($this->getDataFolder() . "config.yml.old");
			@rename($this->getDataFolder() . "config.yml", $this->getDataFolder() . "config.yml.old");

			$this->saveResource("config.yml", TRUE);
			$this->getConfig()->reload();

			$this->getLogger()->notice("Config updated. Old config was renamed to 'config.yml.old'.");
		}

		self::$configuration = new Configuration($this->getConfig()->getAll());
	}

	private function initListener() : void {
		$this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
	}

	private function initMath() : void {
		Math::init();
	}

	private function registerCommands() : void {
		$map = $this->getServer()->getCommandMap();
		NewWand::$commands = [new FillCommand, new FirstPositionCommand, new SecondPositionCommand, new WandCommand];

		foreach (self::$commands as $command) {
			$map->register("NewWand", $command);
		}
	}
}

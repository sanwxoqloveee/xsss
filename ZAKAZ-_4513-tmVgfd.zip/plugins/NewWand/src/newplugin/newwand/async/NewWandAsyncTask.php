<?php

declare(strict_types=1);

namespace newplugin\newwand\async;

use AttachableLogger;
use JetBrains\PhpStorm\Pure;
use newplugin\newwand\NewWand;
use pocketmine\scheduler\AsyncTask;
use Throwable;

abstract class NewWandAsyncTask extends AsyncTask {
	private AttachableLogger $logger;
	private string $error = "";

	#[Pure] public function __construct() {
		$this->logger = NewWand::getInstance()->getLogger();
	}

	abstract public function execute() : void;

	final public function onRun() : void {
		try {
			$this->execute();
		} catch (Throwable $error) {
			$this->error = $error->getMessage();
		}
	}

	/**
	 * This function is called on main thread before calling
	 * callback function
	 */
	public function complete() : void {
	}

	/** @noinspection PhpUnused */
	final public function onCompletion() : void {
		$this->complete();
		AsyncQueue::callCallback($this);
	}

	public function getErrorMessage() : ?string {
		return $this->error === "" ? NULL : $this->error;
	}

	protected function getLogger() : AttachableLogger {
		return $this->logger;
	}
}
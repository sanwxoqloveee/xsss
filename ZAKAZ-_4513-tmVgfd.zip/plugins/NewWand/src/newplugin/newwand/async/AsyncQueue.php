<?php

declare(strict_types=1);

namespace newplugin\newwand\async;

use Closure;
use pocketmine\Server;
use function spl_object_hash;

class AsyncQueue {
	/** @var Closure[] */
	private static array $queue = [];

	/**
	 * @phpstan-param NewWandAsyncTask<mixed> $task
	 * @phpstan-param Closure(NewWandAsyncTask<mixed> $task): void $callback
	 */
	public static function submitTask(NewWandAsyncTask $task, ?Closure $callback = NULL) : void {
		Server::getInstance()->getAsyncPool()->submitTask($task);

		if ($callback !== NULL) {
			self::$queue[spl_object_hash($task)] = $callback;
		}
	}

	/**
	 * @internal
	 *
	 * @phpstan-param NewWandAsyncTask<mixed> $task
	 */
	public static function callCallback(NewWandAsyncTask $task) : void {
		if (!isset(self::$queue[spl_object_hash($task)])) {
			return;
		}

		$callback = self::$queue[spl_object_hash($task)];
		$callback($task);
	}
}
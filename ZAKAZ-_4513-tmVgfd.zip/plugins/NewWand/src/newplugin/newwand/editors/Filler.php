<?php

declare(strict_types=1);

namespace newplugin\newwand\editors;

use newplugin\newwand\editors\object\EditorResult;
use newplugin\newwand\editors\object\FillSession;
use newplugin\newwand\math\Math;
use newplugin\newwand\utils\StringToBlockDecoder;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\SingletonTrait;
use function microtime;

class Filler {
	use SingletonTrait;

	public function directFill(Player $player, Vector3 $pos1, Vector3 $pos2, string $blockArgs, bool $hollow = FALSE) : EditorResult {
		$startTime = microtime(TRUE);

		Math::calculateMinAndMaxValues($pos1, $pos2, TRUE, $minX, $maxX, $minY, $maxY, $minZ, $maxZ);

		$stringToBlockDecoder = new StringToBlockDecoder($blockArgs, $player->getInventory()->getItemInHand());
		if (!$stringToBlockDecoder->isValid()) {
			return EditorResult::error("No blocks specified in string $blockArgs");
		}

		$fillSession = new FillSession($player->getWorld(), FALSE);
		$fillSession->setDimensions($minX, $maxX, $minZ, $maxZ);
		$fillSession->loadChunks($player->getWorld());

		if ($hollow) {
			for ($x = $minX; $x <= $maxX; ++$x) {
				for ($z = $minZ; $z <= $maxZ; ++$z) {
					for ($y = $minY; $y <= $maxY; ++$y) {
						if (($x !== $minX && $x !== $maxX) && ($y !== $minY && $y !== $maxY) && ($z !== $minZ && $z !== $maxZ)) {
							continue;
						}

						$stringToBlockDecoder->nextBlock($fullBlockId);
						$fillSession->setBlockAt($x, $y, $z, $fullBlockId);
					}
				}
			}
		} else {
			for ($x = $minX; $x <= $maxX; ++$x) {
				for ($z = $minZ; $z <= $maxZ; ++$z) {
					for ($y = $minY; $y <= $maxY; ++$y) {
						$stringToBlockDecoder->nextBlock($fullBlockId);
						$fillSession->setBlockAt($x, $y, $z, $fullBlockId);
					}
				}
			}
		}

		$fillSession->reloadChunks($player->getWorld());
		$fillSession->close();

		$updates = $fillSession->getChanges();
		$updates->save();

		return EditorResult::success($fillSession->getBlocksChanged(), microtime(TRUE) - $startTime);
	}

	public function directWalls(Player $player, Vector3 $pos1, Vector3 $pos2, string $blockArgs) : EditorResult {
		$startTime = microtime(TRUE);

		Math::calculateMinAndMaxValues($pos1, $pos2, TRUE, $minX, $maxX, $minY, $maxY, $minZ, $maxZ);

		$stringToBlockDecoder = new StringToBlockDecoder($blockArgs, $player->getInventory()->getItemInHand());
		if (!$stringToBlockDecoder->isValid()) {
			return EditorResult::error("No blocks found in string $blockArgs");
		}

		$fillSession = new FillSession($player->getWorld(), FALSE);
		$fillSession->setDimensions($minX, $maxX, $minZ, $maxZ);
		$fillSession->loadChunks($player->getWorld());

		for ($x = $minX; $x <= $maxX; ++$x) {
			for ($z = $minZ; $z <= $maxZ; ++$z) {
				for ($y = $minY; $y <= $maxY; ++$y) {
					if ($x === $minX || $x === $maxX || $z === $minZ || $z === $maxZ) {
						$stringToBlockDecoder->nextBlock($fullBlockId);
						$fillSession->setBlockAt($x, $y, $z, $fullBlockId);
					}
				}
			}
		}

		$fillSession->reloadChunks($player->getWorld());
		$fillSession->close();

		$updates = $fillSession->getChanges();
		$updates->save();

		return EditorResult::success($fillSession->getBlocksChanged(), microtime(TRUE) - $startTime);
	}
}
<?php

declare(strict_types=1);

namespace newplugin\newwand\editors\object;

use function round;

class EditorResult {
	protected int $blocksChanged = 0;
	protected float $processTime = 0.0;
	protected ?string $errorMessage = NULL;

	protected function __construct() {
	}

	public static function success(int $blocksChanged, float $processTime) : EditorResult {
		$result = new EditorResult();
		$result->blocksChanged = $blocksChanged;
		$result->processTime = round($processTime, 3);

		return $result;
	}

	public static function error(string $message) : EditorResult {
		$result = new EditorResult();
		$result->errorMessage = $message;

		return $result;
	}

	public function getBlocksChanged() : int {
		return $this->blocksChanged;
	}

	public function getProcessTime() : float {
		return $this->processTime;
	}

	public function successful() : bool {
		return $this->errorMessage === NULL;
	}

	public function getErrorMessage() : ?string {
		return $this->errorMessage;
	}
}
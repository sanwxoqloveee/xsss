<?php

declare(strict_types=1);

namespace newplugin\newwand\editors\object;

use newplugin\newwand\blockstorage\identifiers\BlockIdentifierList;
use pocketmine\world\ChunkManager;

class MaskedFillSession extends FillSession {
	protected ?BlockIdentifierList $mask;

	public function __construct(ChunkManager $world, bool $calculateDimensions = TRUE, bool $saveChanges = TRUE, ?BlockIdentifierList $mask = NULL) {
		parent::__construct($world, $calculateDimensions, $saveChanges);

		$this->mask = $mask;
	}

	/**
	 * @param int $y 0-255
	 */
	public function setBlockAt(int $x, int $y, int $z, int $fullBlockId) : void {
		if (!$this->moveTo($x, $y, $z)) {
			return;
		}

		// TODO
		if ($this->mask !== NULL && (
			!$this->mask->containsBlock(
			/** @phpstan-ignore-next-line */
				$this->explorer->currentSubChunk->getFullBlock($x & 0xf, $y & 0xf, $z & 0xf)
			)) && (
			!$this->mask->containsBlockId(
			/** @phpstan-ignore-next-line */
				$this->explorer->currentSubChunk->getFullBlock($x & 0xf, $y & 0xf, $z & 0xf) >> 4)
			)
		) {
			return;
		}

		$this->saveChanges($x, $y, $z);

		/** @phpstan-ignore-next-line */
		$this->explorer->currentSubChunk->setFullBlock($x & 0xf, $y & 0xf, $z & 0xf, $fullBlockId);
		$this->blocksChanged++;
	}

	/**
	 * @param int $y 0-255
	 */
	public function setBlockIdAt(int $x, int $y, int $z, int $id) : void {
		if (!$this->moveTo($x, $y, $z)) {
			return;
		}

		if ($this->mask !== NULL && !$this->mask->containsBlock(
			/** @phpstan-ignore-next-line */
				$this->explorer->currentSubChunk->getFullBlock($x & 0xf, $y & 0xf, $z & 0xf))
		) {
			return;
		}

		$this->saveChanges($x, $y, $z);

		/** @phpstan-ignore-next-line */
		$this->explorer->currentSubChunk->setFullBlock($x & 0xf, $y & 0xf, $z & 0xf, $id);
		$this->blocksChanged++;
	}
}
<?php

declare(strict_types=1);

namespace newplugin\newwand\blockstorage;

use pocketmine\world\ChunkManager;

interface UpdateLevelData {
	/**
	 * @return bool Returns if it is possible read next blocks
	 */
	public function hasNext() : bool;

	/**
	 * Reads next block from the array
	 */
	public function readNext(?int &$x, ?int &$y, ?int &$z, ?int &$fullBlockId) : void;

	/**
	 * Should not be null when used in filler
	 */
	public function getWorld() : ?ChunkManager;
}
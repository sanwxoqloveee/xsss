<?php

declare(strict_types=1);

namespace newplugin\newwand\blockstorage;

use newplugin\newwand\NewWand;
use pocketmine\math\Vector3;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\TreeRoot;
use pocketmine\world\ChunkManager;
use pocketmine\world\World;
use RuntimeException;
use Serializable;
use function array_combine;
use function array_keys;
use function array_reverse;
use function array_slice;
use function array_values;
use function count;
use function in_array;
use function is_string;
use function pack;
use function unpack;
use function zlib_decode;
use function zlib_encode;
use const ZLIB_ENCODING_GZIP;

class BlockArray implements UpdateLevelData, Serializable {
	/** @var int[] */
	public array $blocks = [];
	/** @var int[] */
	public array $coords = [];
	public string $compressedBlocks;
	public string $compressedCoords;
	public int $offset = 0;
	protected ?BlockArraySizeData $sizeData = NULL;
	protected ?ChunkManager $world = NULL;
	protected bool $detectDuplicates;
	protected bool $isCompressed = FALSE;
	/**
	 * Fields to avoid allocating memory every time
	 * when writing or reading block from the
	 * array
	 */
	protected int $lastHash;

	public function __construct(bool $detectDuplicates = FALSE) {
		$this->detectDuplicates = $detectDuplicates;
	}

	/**
	 * Adds block to the block array
	 *
	 * @return $this
	 */
	public function addBlock(Vector3 $vector3, int $fullBlockId) : BlockArray {
		return $this->addBlockAt($vector3->getFloorX(), $vector3->getFloorY(), $vector3->getFloorZ(), $fullBlockId);
	}

	/**
	 * Adds block to the block array
	 *
	 * @return $this
	 */
	public function addBlockAt(int $x, int $y, int $z, int $fullBlockId) : BlockArray {
		$this->lastHash = World::blockHash($x, $y, $z);

		if ($this->detectDuplicates && in_array($this->lastHash, $this->coords, TRUE)) {
			return $this;
		}

		$this->coords[] = $this->lastHash;
		$this->blocks[] = $fullBlockId;

		return $this;
	}

	/**
	 * Returns if it is possible read next block from the array
	 */
	public function hasNext() : bool {
		return $this->offset < count($this->blocks);
	}

	/**
	 * Reads next block in the array
	 */
	public function readNext(?int &$x, ?int &$y, ?int &$z, ?int &$fullBlockId) : void {
		$this->lastHash = $this->coords[$this->offset];

		World::getBlockXYZ($this->lastHash, $x, $y, $z);
		$fullBlockId = $this->blocks[$this->offset++];
	}

	/**
	 * @return int $size
	 */
	public function size() : int {
		return count($this->coords);
	}

	/**
	 * Adds Vector3 to all the blocks in BlockArray
	 */
	public function addVector3(Vector3 $vector3) : BlockArray {
		$floorX = $vector3->getFloorX();
		$floorY = $vector3->getFloorY();
		$floorZ = $vector3->getFloorZ();

		$blockArray = new BlockArray();
		$blockArray->blocks = $this->blocks;

		foreach ($this->coords as $hash) {
			World::getBlockXYZ($hash, $x, $y, $z);
			$blockArray->coords[] = World::blockHash(($floorX + $x), ($floorY + $y), ($floorZ + $z));
		}

		return $blockArray;
	}

	/**
	 * Subtracts Vector3 from all the blocks in BlockArray
	 */
	public function subtractVector3(Vector3 $vector3) : BlockArray {
		return $this->addVector3($vector3->multiply(-1));
	}

	/**
	 * @return BlockArraySizeData is used for calculating dimensions
	 */
	public function getSizeData() : BlockArraySizeData {
		if ($this->sizeData === NULL) {
			$this->sizeData = new BlockArraySizeData($this);
		}

		return $this->sizeData;
	}

	public function getWorld() : ?ChunkManager {
		return $this->world;
	}

	public function setWorld(?ChunkManager $level) : self {
		$this->world = $level;

		return $this;
	}

	/**
	 * @return int[]
	 */
	public function getBlockArray() : array {
		return $this->blocks;
	}

	/**
	 * @return int[]
	 */
	public function getCoordsArray() : array {
		return $this->coords;
	}

	public function removeDuplicates() : void {
		if (!(NewWand::getConfiguration()->getBoolProperty("remove-duplicate-blocks"))) {
			return;
		}

		// TODO - Optimize this
		$blocks = array_combine(array_reverse($this->coords, TRUE), array_reverse($this->blocks, TRUE));

		$this->coords = array_keys($blocks);
		$this->blocks = array_values($blocks);
	}

	public function save() : void {
		if (NewWand::getConfiguration()->getBoolProperty("clipboard-compression")) {
			$this->compress();
			$this->isCompressed = TRUE;
		}
	}

	public function load() : void {
		if (NewWand::getConfiguration()->getBoolProperty("clipboard-compression")) {
			$this->decompress();
			$this->isCompressed = FALSE;
		}
	}

	public function compress(bool $cleanDecompressed = TRUE) : void {
		/** @phpstan-var string $coords */
		$coords = pack("q*", ...$this->coords);
		/** @phpstan-var string $blocks */
		$blocks = pack("N*", ...$this->blocks);

		$this->compressedCoords = $coords;
		$this->compressedBlocks = $blocks;

		if ($cleanDecompressed) {
			$this->coords = [];
			$this->blocks = [];
		}
	}

	public function decompress(bool $cleanCompressed = TRUE) : void {
		/** @phpstan-var int[]|false $coords */
		$coords = unpack("q*", $this->compressedCoords);
		/** @phpstan-var int[]|false $coords */
		$blocks = unpack("N*", $this->compressedBlocks);

		if ($coords === FALSE || $blocks === FALSE) {
			throw new RuntimeException("Error whilst decompressing");
		}

		$this->coords = array_values($coords);
		$this->blocks = array_values($blocks);

		if ($cleanCompressed) {
			unset($this->compressedCoords);
			unset($this->compressedBlocks);
		}
	}

	public function isCompressed() : bool {
		return $this->isCompressed;
	}

	/**
	 * Removes all the blocks whose were checked already
	 * For cleaning duplicate cache use cancelDuplicateDetection()
	 */
	public function cleanGarbage() : void {
		$this->coords = array_slice($this->coords, $this->offset);
		$this->blocks = array_slice($this->blocks, $this->offset);

		$this->offset = 0;
	}

	public function serialize() : ?string {
		$this->compress();

		$nbt = new CompoundTag();
		$nbt->setByteArray("Coords", $this->compressedCoords);
		$nbt->setByteArray("Blocks", $this->compressedBlocks);
		$nbt->setByte("DuplicateDetection", $this->detectDuplicates ? 1 : 0);

		$serializer = new BigEndianNbtSerializer();
		$buffer = zlib_encode($serializer->write(new TreeRoot($nbt)), ZLIB_ENCODING_GZIP);

		if ($buffer === FALSE) {
			return NULL;
		}

		return $buffer;
	}

	public function unserialize($data) : void {
		if (!is_string($data)) {
			return;
		}

		if (!($data = zlib_decode($data))) {
			return;
		}

		/** @var CompoundTag $nbt */
		$nbt = (new BigEndianNbtSerializer())->read($data)->getTag();
		if (!$nbt->getTag("Coords") instanceof ByteArrayTag || !$nbt->getTag("Blocks") instanceof ByteArrayTag || !$nbt->getTag("DuplicateDetection") instanceof ByteTag) {
			return;
		}

		$this->compressedCoords = $nbt->getByteArray("Coords");
		$this->compressedBlocks = $nbt->getByteArray("Blocks");
		$this->detectDuplicates = $nbt->getByte("DuplicateDetection") === 1;

		$this->decompress();
	}
}
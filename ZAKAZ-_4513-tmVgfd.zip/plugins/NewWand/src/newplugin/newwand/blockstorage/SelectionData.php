<?php

declare(strict_types=1);

namespace newplugin\newwand\blockstorage;

use InvalidArgumentException;
use pocketmine\math\Vector3;
use pocketmine\world\World;
use function pack;
use function unpack;

class SelectionData extends BlockArray {
	public string $compressedPlayerPosition;
	protected Vector3 $playerPosition;

	public static function fromBlockArray(BlockArray $blockArray, Vector3 $playerPosition) : SelectionData {
		$selectionData = new SelectionData();
		$selectionData->setPlayerPosition($playerPosition);
		$selectionData->setWorld($blockArray->getWorld());
		$selectionData->blocks = $blockArray->getBlockArray();
		$selectionData->coords = $blockArray->getCoordsArray();

		return $selectionData;
	}

	/**
	 * @param bool $modifyBuffer If it's false, only relative position will be changed.
	 */
	public function addVector3(Vector3 $vector3, bool $modifyBuffer = FALSE) : BlockArray {
		if (!$vector3->floor()->equals($vector3)) {
			throw new InvalidArgumentException("Vector3 coordinates must be integer.");
		}

		if (isset($this->playerPosition)) {
			$clipboard = clone $this;
			$clipboard->playerPosition->addVector($vector3);

			return $clipboard;
		}

		return parent::addVector3($vector3);
	}

	public function getPlayerPosition() : Vector3 {
		return $this->playerPosition;
	}

	/**
	 * @return $this
	 */
	public function setPlayerPosition(Vector3 $playerPosition) : SelectionData {
		$this->playerPosition = $playerPosition->floor();

		return $this;
	}

	public function compress(bool $cleanDecompressed = TRUE) : void {
		parent::compress($cleanDecompressed);

		if (!isset($this->playerPosition)) {
			return;
		}

		$vector3 = $this->getPlayerPosition();
		$this->compressedPlayerPosition = pack("q", World::blockHash($vector3->getFloorX(), $vector3->getFloorY(), $vector3->getFloorZ()));

		unset($this->playerPosition);
	}

	public function decompress(bool $cleanCompressed = TRUE) : void {
		parent::decompress($cleanCompressed);

		if (!isset($this->compressedPlayerPosition)) {
			return;
		}

		/** @phpstan-ignore-next-line */
		World::getBlockXYZ((int) (unpack("q", $this->compressedPlayerPosition)[1]), $x, $y, $z);
		$this->playerPosition = new Vector3($x, $y, $z);
	}
}
<?php

declare(strict_types=1);

namespace newplugin\newwand\blockstorage\identifiers;

interface BlockIdentifierList {
	/**
	 * Function which outputs next random block
	 */
	public function nextBlock(?int &$fullBlockId) : void;

	/**
	 * Function which returns if the block
	 * in the list
	 */
	public function containsBlock(int $fullBlockId) : bool;

	/**
	 * Returns if the id is on the list
	 */
	public function containsBlockId(int $id) : bool;
}
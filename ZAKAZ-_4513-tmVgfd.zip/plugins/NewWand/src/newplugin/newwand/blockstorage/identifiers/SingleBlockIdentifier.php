<?php

declare(strict_types=1);

namespace newplugin\newwand\blockstorage\identifiers;

use JetBrains\PhpStorm\Pure;

class SingleBlockIdentifier implements BlockIdentifierList {
	protected int $id;
	protected int $meta;

	public function __construct(int $id, ?int $meta = NULL) {
		$this->id = $id;
		if ($meta !== NULL) {
			$this->meta = $meta;
		}
	}

	#[Pure]public static function airIdentifier() : SingleBlockIdentifier {
		return new SingleBlockIdentifier(0);
	}

	public function nextBlock(?int &$fullBlockId) : void {
		$fullBlockId = $this->id << 4 | $this->meta;
	}

	public function containsBlock(int $fullBlockId) : bool {
		return isset($this->meta) ? $fullBlockId === ($this->id << 4 | $this->meta) : $fullBlockId >> 4 === $this->id;
	}

	public function containsBlockId(int $id) : bool {
		return $this->id === $id;
	}
}
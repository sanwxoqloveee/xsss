<?php

declare(strict_types=1);

namespace newplugin\newwand\utils;

use newplugin\newwand\blockstorage\identifiers\BlockIdentifierList;
use OutOfBoundsException;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use function array_rand;
use function count;
use function explode;
use function in_array;
use function is_numeric;
use function min;
use function str_replace;
use function strpos;
use function substr;

final class StringToBlockDecoder implements BlockIdentifierList {
	private string $string;
	private ?string $itemInHand = NULL;
	/** @var int[] */
	private array $blockIdMap = [];
	/** @var int[] */
	private array $blockMap = [];

	public function __construct(string $string, ?Item $handItem = NULL, bool $mixBlockIds = TRUE) {
		$this->string = $string;

		if ($handItem !== NULL) {
			$this->itemInHand = "{$handItem->getId()}:{$handItem->getMeta()}";
		}

		$this->decode($mixBlockIds);
	}

	/**
	 * @return bool Returns if the string contains
	 * any valid blocks
	 */
	public function isValid(bool $requireBlockMap = TRUE) : bool {
		return count($this->blockMap) !== 0 || (!$requireBlockMap && count($this->blockIdMap) !== 0);
	}

	/**
	 * Reads next block from the string,
	 * @throws OutOfBoundsException if string is not valid.
	 */
	public function nextBlock(?int &$fullBlockId) : void {
		$fullBlockId = $this->blockMap[array_rand($this->blockMap)];
	}

	/**
	 * @return bool Returns if the block is in the array
	 */
	public function containsBlock(int $fullBlockId) : bool {
		return in_array($fullBlockId, $this->blockMap, TRUE);
	}

	/**
	 * @return bool Returns if block id is in the array
	 */
	public function containsBlockId(int $id) : bool {
		return in_array($id, $this->blockIdMap, TRUE);
	}

	/**
	 * @param bool $mixBlockIds If enabled, block ids will be saved
	 * to both block and blockId maps
	 */
	public function decode(bool $mixBlockIds = TRUE) : void {
		if ($this->itemInHand !== NULL) {
			$this->string = str_replace("hand", $this->itemInHand, $this->string);
		}

		$split = explode(",", str_replace(";", ",", $this->string));
		foreach ($split as $entry) {
			$count = 1;
			$block = $entry;
			if (($pos = strpos($entry, "%")) !== FALSE) {
				$p = substr($entry, 0, $pos);
				if (!is_numeric($p)) {
					continue;
				}

				$count = min(100, (int) $p);
				$block = substr($entry, $pos + 1);
			}

			$item = StringToItemParser::getInstance()->parse($block);
			if ($item === NULL) {
				continue;
			}

			$class = $item->getBlock();
			if ($class->getId() === 0 && $item->getId() !== 0) {
				continue;
			}

			if (!$mixBlockIds) {
				if (str_contains($entry, ":")) { // Meta is specified
					for ($i = 0; $i < $count; ++$i) {
						$this->blockMap[] = $class->getId() << 4 | $class->getMeta();
					}
				} else {
					for ($i = 0; $i < $count; ++$i) {
						$this->blockIdMap[] = $class->getId();
					}
				}
				continue;
			}

			for ($i = 0; $i < $count; ++$i) {
				$this->blockIdMap[] = $class->getId();
				$this->blockMap[] = $class->getId() << 4 | $class->getMeta();
			}
		}
	}
}
<?php

declare(strict_types=1);

namespace newplugin\newwand\utils;

use Exception;

class IncompatibleConfigException extends Exception {
}
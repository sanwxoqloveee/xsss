<?php

declare(strict_types=1);

namespace newplugin\newwand\commands;

use JetBrains\PhpStorm\Pure;
use newplugin\newwand\NewWand;
use newplugin\newwand\Selectors;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginOwned;
use pocketmine\world\Position;
use RuntimeException;
use function str_replace;
use function strtolower;

abstract class NewWandCommand extends Command implements PluginOwned {
	public function __construct(string $name, string $description = "", string $usageMessage = NULL, $aliases = []) {
		$this->setPermission($this->getPerms($name));
		parent::__construct($name, $description, $usageMessage, $aliases);
	}

	/** @noinspection PhpUnused */
	public function execute(CommandSender $sender, string $commandLabel, array $args) {
		$permission = $this->getPermission();
		if ($permission === NULL) {
			throw new RuntimeException("Command " . __CLASS__ . " is registered wrong.");
		}

		if (!$sender->hasPermission($permission)) {
			$sender->sendMessage((string) $this->getPermissionMessage());
		}
	}

	#[Pure] public function getOwningPlugin() : Plugin {
		return NewWand::getInstance();
	}

	protected function readPositions(Player $sender, ?Position &$firstPos = NULL, ?Position &$secondPos = NULL) : bool {
		if (!Selectors::isSelected(1, $sender)) {
			$sender->sendMessage(NewWand::getPrefix() . "§cСначала установите первую позицию.");
			return FALSE;
		}
		if (!Selectors::isSelected(2, $sender)) {
			$sender->sendMessage(NewWand::getPrefix() . "§cУстановите вторую позицию.");
			return FALSE;
		}

		$firstPos = Selectors::getPosition($sender, 1);
		$secondPos = Selectors::getPosition($sender, 2);

		if ($firstPos->getWorld()->getId() !== $secondPos->getWorld()->getId()) {
			$sender->sendMessage(NewWand::getPrefix() . "§cПозиции в разных мирах.");
			return FALSE;
		}

		return TRUE;
	}

	private function getPerms(string $name) : string {
		return "newwand.command." . str_replace("/", "", strtolower($name));
	}
}
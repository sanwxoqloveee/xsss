<?php

declare(strict_types=1);

namespace newplugin\newwand\commands;

use newplugin\newwand\NewWand;
use newplugin\newwand\Selectors;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\Position;
use function is_int;

class SecondPositionCommand extends NewWandCommand {
	public function __construct() {
		parent::__construct("/pos2", "Установить вторую позицию", NULL, ["/2"]);
	}

	/** @noinspection PhpUnused */
	public function execute(CommandSender $sender, string $commandLabel, array $args) {
		if (!$this->testPermission($sender)) return;

		if (!$sender instanceof Player) {
			$sender->sendMessage("§cТолько в игре!");
			return;
		}
		$size = Selectors::addSelector($sender, 2, $position = new Position((int) $sender->getPosition()->getX(), (int) $sender->getPosition()->getY(), (int) $sender->getPosition()->getZ(), $sender->getWorld()));
		$sender->sendMessage(NewWand::getPrefix() . "§aВторая позиция установлена в {$position->getX()}, {$position->getY()}, {$position->getZ()}" . (is_int($size) ? " ($size)" : ""));
	}
}
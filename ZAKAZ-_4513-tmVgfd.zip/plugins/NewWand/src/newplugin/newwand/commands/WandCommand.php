<?php

declare(strict_types=1);

namespace newplugin\newwand\commands;

use newplugin\newwand\NewWand;
use newplugin\newwand\Selectors;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ListTag;
use pocketmine\player\Player;

class WandCommand extends NewWandCommand {
	public function __construct() {
		parent::__construct("/wand", "Получить топорик", NULL, []);
	}

	/** @noinspection PhpUnused */
	public function execute(CommandSender $sender, string $commandLabel, array $args) {
		if (!$this->testPermission($sender)) return;
		if (!$sender instanceof Player) {
			$sender->sendMessage("§cТолько в игре!");
			return;
		}

		if (NewWand::getConfiguration()->getBoolProperty("wand-axe.enabled")) {
			$item = VanillaItems::WOODEN_AXE();
			$item->setCustomName(NewWand::getConfiguration()->getStringProperty("wand-axe.name"));
			$item->getNamedTag()->setTag(Item::TAG_ENCH, new ListTag([], NBT::TAG_Compound));
			$item->getNamedTag()->setByte("newwand", 1);

			$sender->getInventory()->addItem($item);
			$sender->sendMessage(NewWand::getPrefix() . "§aВам был выдан топорик!");
			return;
		}

		Selectors::switchWandSelector($sender);
		$switch = Selectors::isWandSelector($sender) ? "включён" : "выключен";
		$sender->sendMessage(NewWand::getPrefix() . "§aТопорик был $switch!");
	}
}
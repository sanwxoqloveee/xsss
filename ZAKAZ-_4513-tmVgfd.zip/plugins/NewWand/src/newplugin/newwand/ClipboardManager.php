<?php

declare(strict_types=1);

namespace newplugin\newwand;

use JetBrains\PhpStorm\Pure;
use newplugin\newwand\blockstorage\BlockArray;
use newplugin\newwand\blockstorage\SelectionData;
use pocketmine\player\Player;
use function array_key_exists;
use function array_pop;

class ClipboardManager {
	/** @var SelectionData[] */
	public static array $clipboards = [];
	/** @var BlockArray[][] */
	public static array $undoData = [];
	/** @var BlockArray[][] */
	public static array $redoData = [];

	#[Pure] public static function getClipboard(Player $player) : ?SelectionData {
		return array_key_exists($player->getName(), self::$clipboards) ? clone self::$clipboards[$player->getName()] : NULL;
	}

	#[Pure] public static function hasClipboardCopied(Player $player) : bool {
		return array_key_exists($player->getName(), self::$clipboards);
	}

	public static function saveClipboard(Player $player, SelectionData $data) : void {
		self::$clipboards[$player->getName()] = $data;
	}

	public static function getNextUndoAction(Player $player) : ?BlockArray {
		return array_pop(self::$undoData[$player->getName()]);
	}

	#[Pure] public static function hasActionToUndo(Player $player) : bool {
		return array_key_exists($player->getName(), self::$undoData) && !empty(self::$undoData[$player->getName()]);
	}

	public static function saveUndo(Player $player, BlockArray $array) : void {
		self::$undoData[$player->getName()][] = $array;
	}

	public static function getNextRedoAction(Player $player) : ?BlockArray {
		return array_pop(self::$redoData[$player->getName()]);
	}

	#[Pure] public static function hasActionToRedo(Player $player) : bool {
		return array_key_exists($player->getName(), self::$redoData) && !empty(self::$redoData[$player->getName()]);
	}

	public static function saveRedo(Player $player, BlockArray $array) : void {
		self::$redoData[$player->getName()][] = $array;
	}
}
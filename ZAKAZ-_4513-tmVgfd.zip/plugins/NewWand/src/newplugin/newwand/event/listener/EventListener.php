<?php

declare(strict_types=1);

namespace newplugin\newwand\event\listener;

use newplugin\newwand\blockstorage\OfflineSession;
use newplugin\newwand\NewWand;
use newplugin\newwand\Selectors;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\ItemIds;
use pocketmine\nbt\tag\ByteTag;
use function is_int;
use function microtime;

class EventListener implements Listener {
	/** @var float[] */
	private array $wandClicks = [];
	/** @var float[] */
	private array $blockInfoClicks = [];

	/** @noinspection PhpUnused */
	public function onBlockBreak(BlockBreakEvent $event) : void {
		if (Selectors::isWandSelector($player = $event->getPlayer()) || ($event->getItem()->getId() === ItemIds::WOODEN_AXE && $event->getItem()->getNamedTag()->getTag("newwand") instanceof ByteTag)) {
			$size = Selectors::addSelector($player, 1, $position = $event->getBlock()->getPosition());
			$player->sendMessage(NewWand::getPrefix() . "§aПервая позиция установлена в {$position->getX()}, {$position->getY()}, {$position->getZ()}" . (is_int($size) ? " ($size)" : ""));
			$event->cancel();
		}
	}

	/** @noinspection PhpUnused */
	public function onBlockTouch(PlayerInteractEvent $event) : void {
		if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
		if (Selectors::isWandSelector($player = $event->getPlayer()) || ($event->getItem()->getId() === ItemIds::WOODEN_AXE && $event->getItem()->getNamedTag()->getTag("newwand") instanceof ByteTag)) {
			if (isset($this->wandClicks[$player->getName()]) && microtime(TRUE) - $this->wandClicks[$player->getName()] < 0.5) {
				return;
			}

			$this->wandClicks[$player->getName()] = microtime(TRUE);
			$size = Selectors::addSelector($player, 2, $position = $event->getBlock()->getPosition());
			$player->sendMessage(NewWand::getPrefix() . "§aВторая позиция установлена в {$position->getX()}, {$position->getY()}, {$position->getZ()}" . (is_int($size) ? " ($size)" : ""));
			$event->cancel();
		}

		if (Selectors::isBlockInfoPlayer($player = $event->getPlayer()) || ($event->getItem()->getId() === ItemIds::STICK && $event->getItem()->getNamedTag()->getTag("newwand") instanceof ByteTag)) {
			// antispam ._.
			if (isset($this->blockInfoClicks[$player->getName()]) && microtime(TRUE) - $this->blockInfoClicks[$player->getName()] < 0.5) {
				return;
			}

			$block = $event->getBlock();
			$this->blockInfoClicks[$player->getName()] = microtime(TRUE);

			$world = $block->getPosition()->getWorld();

			$player->sendTip("§aID: §7" . $block->getId() . ":" . $block->getMeta() . "\n" . "§aName: §7" . $block->getName() . "\n" . "§aPosition: §7" . $block->getPosition()->getFloorX() . ";" . $block->getPosition()->getFloorY() . ";" . $block->getPosition()->getFloorZ() . " (" . ($block->getPosition()->getFloorX() >> 4) . ";" . ($block->getPosition()->getFloorZ() >> 4) . ")\n" . "§World: §7" . $world->getDisplayName() . "\n" . "§aBiome: §7" . $block->getPosition()->getWorld()->getBiomeId($block->getPosition()->getFloorX(), $block->getPosition()->getFloorZ()) . " (" . $block->getPosition()->getWorld()->getBiome($block->getPosition()->getFloorX(), $block->getPosition()->getFloorZ())->getName() . ")");
		}
	}

	/** @noinspection PhpUnused */
	public function onJoin(PlayerJoinEvent $event) : void {
		OfflineSession::loadPlayerSession($event->getPlayer());
	}

	/** @noinspection PhpUnused */
	public function onQuit(PlayerQuitEvent $event) : void {
		OfflineSession::savePlayerSession($event->getPlayer());
		Selectors::unloadPlayer($event->getPlayer());
	}
}
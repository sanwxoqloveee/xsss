<?php
declare(strict_types=1);

namespace tobias14\clearlag\utils;

use Exception;

class ParseTimeException extends Exception
{

}

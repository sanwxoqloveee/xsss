<?php

declare(strict_types=1);

namespace fernanACM\EnderChest\libs\muqsit\invmenu\session;

use fernanACM\EnderChest\libs\muqsit\invmenu\InvMenu;
use fernanACM\EnderChest\libs\muqsit\invmenu\type\graphic\InvMenuGraphic;

final class InvMenuInfo{

	public function __construct(
		public InvMenu $menu,
		public InvMenuGraphic $graphic
	){}
}
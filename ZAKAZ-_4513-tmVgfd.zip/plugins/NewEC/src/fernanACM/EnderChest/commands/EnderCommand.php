<?php

namespace fernanACM\EnderChest\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
# Lib - InvMenu
use fernanACM\EnderChest\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use fernanACM\EnderChest\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use fernanACM\EnderChest\libs\muqsit\invmenu\type\InvMenuTypeIds;
use fernanACM\EnderChest\libs\muqsit\invmenu\InvMenu;
# Lib - Commando
use fernanACM\EnderChest\libs\CortexPE\Commando\BaseCommand;

use fernanACM\EnderChest\Ender;
use fernanACM\EnderChest\utils\PluginUtils;

class EnderCommand extends BaseCommand{
    
    protected function prepare(): void{
        $this->setPermission("newplugin.ec");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void{
        if (!$sender instanceof Player) {
              $sender->sendMessage("Только в игре!");
               return;
        }
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName(Ender::getInstance()->config->get("Settings")["EnderChest-name"]);
        $inv = $menu->getInventory();
        $inv->setContents($sender->getEnderInventory()->getContents());
        $menu->setListener(function (InvMenuTransaction $transaction) use ($sender): InvMenuTransactionResult{
        $sender->getEnderInventory()->setItem($transaction->getAction()->getSlot(), $transaction->getIn());
        return $transaction->continue();
        });
        $menu->send($sender);
        if(Ender::getInstance()->config->get("Settings")["EnderChest-no-sound"]){
            PluginUtils::PlaySound($sender, Ender::getInstance()->config->get("Settings")["EnderChest-sound"], 50, 1);   
        }
    }
}

<?php

declare(strict_types=1);

namespace NewPlugin\NewEssentials;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener {
	/**
	 * Функция включения. Нужна
	 * для регистрации {@link Listener}.
	 *
	 * @return void
	 */
	public function onEnable() : void {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	/**
	 * Данная функция отвечает за команды плагина.
	 *
	 * @param CommandSender $sender отправитель команды
	 * @param Command $command команда
	 * @param string $label то, что написал игрок
	 * @param array $args аргументы команды
	 * @return bool
	 */
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
		if (!($sender instanceof Player)) {
			$sender->sendMessage("§f(§cAPI§f) Данную команду можно использовать только в игре!");
			return TRUE;
		}
		switch ($command->getName()) {
			case "gms": {
				$sender->setGamemode(GameMode::SURVIVAL());
				$sender->sendMessage("§f(§cAPI§f) Ваш режим игры был изменён на §cВыживание§f.");
				return TRUE;
			}
			case "gmc": {
				$sender->setGamemode(GameMode::CREATIVE());
				$sender->sendMessage("§f(§cAPI§f) Ваш режим игры был изменён на §cКреатив§f.");
				return TRUE;
			}
			case "day": {
				$sender->getWorld()->setTime(0);
				$sender->sendMessage("§f(§cAPI§f) Время в мире было установлено на §cДень§f.");
				return TRUE;
			}
			case "night": {
				$sender->getWorld()->setTime(15000);
				$sender->sendMessage("§f(§cAPI§f) Время в мире было установлено на §cНочь§f.");
				return TRUE;
			}
			case "vanish": {
				$bool = !$sender->isInvisible();
				$sender->setInvisible($bool);
				$sender->setNameTagVisible($bool);
				$sender->sendMessage("§f(§cAPI§f) Невидимость была §cуспешно§f " . ($bool ? "включена" : "отключена") . ".");
				return TRUE;
			}
			case "vanishlist": {
				$i = 0;
				$list = "§f(§cAPI§f) Список §cневидимых§f игроков:";

				foreach ($this->getServer()->getOnlinePlayers() as $player) {
					if ($player->isInvisible()) {
						$list .= ($i === 0 ? "" : "§f, ") . "§c{$player->getDisplayName()}";
						$i++;
					}
				}

				$sender->sendMessage($list);
				return TRUE;
			}
			case "fly": {
				$bool = !$sender->getAllowFlight();
				$sender->setFlying($bool);
				$sender->setAllowFlight($bool);
				$sender->sendMessage("§f(§cAPI§f) Полёт §cуспешно§f " . ($bool ? "включён" : "отключён") . ".");
				return TRUE;
			}
			case "near": {
				$text = "§f(§cAPI§f) Игроки рядом с вами:";
				$pos1 = $sender->getLocation()->getYaw();
				$sPos = $sender->getPosition()->asVector3();
				$i = 0;
				foreach ($sender->getWorld()->getNearbyEntities($sender->getBoundingBox()->expandedCopy(200, 200, 200)) as $entity) {
					if ($entity instanceof Player && $entity->getName() !== $sender->getName()) {
						$i++;
						$r = $pos1 - $entity->getLocation()->getYaw();
						if ($r >= 0 && $r <= 90) {
							$txt = "вперёд ⬆";
						} elseif ($r > 90 && $r <= 180) {
							$txt = "влево ⬅";
						} elseif ($r > 180 && $r <= 270) {
							$txt = "вниз ⬇";
						} elseif ($r > 270 && $r <= 360) {
							$txt = "вправо ➡";
						} elseif ($r <= 0 && $r >= -90) {
							$txt = "назад ⬇";
						} elseif ($r > -90 && $r >= -180) {
							$txt = "вправо ➡";
						} elseif ($r > -180 && $r >= -270) {
							$txt = "вперёд ⬆";
						} elseif ($r > -270 && $r >= -360) {
							$txt = "влево ⬅";
						} else {
							$txt = "Ошибка";
						}
						$text .= "\n§c{$entity->getDisplayName()}§f: §c{$sPos->distance($entity->getPosition()->asVector3())}§f блоков §c{$txt}§f.";
					}
				}
				if ($i === 0) {
					$text .= "\n§cИгроков нет!";
				}
				$sender->sendMessage($text);
				return TRUE;
			}
			default: {
				return TRUE;
			}
		}
	}
}

<?php

declare(strict_types=1);

namespace NewPlugin\NewBowTP;

use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener {
	public function onEnable() : void {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function onProjectile(ProjectileHitEvent $event) {
		$player = ($entity = $event->getEntity())->getOwningEntity();
		if (!($player instanceof Player) || !$player->hasPermission("newplugin.bowtp")) return;
		$player->teleport($entity->getPosition());
		$player->sendMessage("§f(§cЛук§f) Вы были телепортированы к стреле.");
	}
}